class CreateAccounts < ActiveRecord::Migration[7.2]
  def change
    create_table :accounts do |t|
      t.decimal :balance, precision: 15, scale: 2, default: 0.0, null: false
      t.references :user, null: false, foreign_key: true
      t.timestamps
    end
  end
end
