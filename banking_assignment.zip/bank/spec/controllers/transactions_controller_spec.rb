require 'rails_helper'

RSpec.describe TransactionsController, type: :controller do
  let(:account) { Account.create!(balance: 1000) }

  describe "GET #deposit" do
    it "renders the deposit page" do
      get :deposit, params: { account_id: account.id }
      expect(response).to be_successful
    end
  end

  describe "POST #deposit" do
    it "increases the account balance" do
      post :deposit, params: { account_id: account.id, amount: 200 }
      expect(account.reload.balance).to eq(1200)
      expect(response).to redirect_to(account_path(account))
      expect(flash[:notice]).to match(/deposited/i)
    end
  end

  describe "GET #withdrawal" do
    it "renders withdrawal form" do
      get :withdrawal, params: { account_id: account.id }
      expect(response).to be_successful
    end
  end

  describe "POST #withdrawal" do
    context "with sufficient balance" do
      it "reduces the account balance" do
        post :withdrawal, params: { account_id: account.id, amount: 400 }
        expect(account.reload.balance).to eq(600)
        expect(response).to redirect_to(account_path(account))
        expect(flash[:notice]).to match(/Successfully withdrew/i)
      end
    end

    context "with insufficient balance" do
      it "renders withdrawal again with alert" do
        post :withdrawal, params: { account_id: account.id, amount: 2000 }
        expect(response).to render_template(:withdrawal)
        expect(flash[:alert]).to eq("Insufficient balance!")
      end
    end
  end

  describe "POST #transfer" do
    let(:target_account) { Account.create!(balance: 300) }

    it "transfers amount between accounts" do
      post :transfer, params: {
        account_id: account.id,
        target_account_id: target_account.id,
        amount: 200
      }
      expect(account.reload.balance).to eq(800)
      expect(target_account.reload.balance).to eq(500)
      expect(flash[:notice]).to match(/Transfer successful/i)
    end
  end
end
