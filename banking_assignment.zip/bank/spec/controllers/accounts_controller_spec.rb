require 'rails_helper'

RSpec.describe AccountsController, type: :controller do
  let(:valid_attributes) do
    {
      name: "John Doe",
      address: "Hyderabad",
      phone: "9876543210",
      dob: Date.new(1990, 1, 1),
      initial_deposit: 1000
    }
  end

  let(:invalid_attributes) do
    {
      name: "",  # invalid, required field missing
      address: "Hyderabad",
      phone: "9876543210",
      dob: Date.new(1990, 1, 1),
      initial_deposit: 1000
    }
  end

  describe "GET #new" do
    it "assigns a new User to @user" do
      get :new
      expect(assigns(:user)).to be_a_new(User)
      expect(response).to be_successful
    end
  end

  describe "POST #create" do
    context "with valid parameters" do
      it "creates a new User" do
        expect {
          post :create, params: { user: valid_attributes }
        }.to change(User, :count).by(1)
      end

      it "creates an associated Account" do
        expect {
          post :create, params: { user: valid_attributes }
        }.to change(Account, :count).by(1)
      end

      it "sets account balance to initial_deposit" do
        post :create, params: { user: valid_attributes }
        account = Account.last
        expect(account.balance).to eq(1000.0)
      end

      it "redirects to the user's account page with a success notice" do
        post :create, params: { user: valid_attributes }
        account = Account.last
        expect(response).to redirect_to(account_path(account))
        expect(flash[:notice]).to eq("Account successfully created!")
      end
    end

    context "with invalid parameters" do
      it "does not create a new user" do
        expect {
          post :create, params: { user: invalid_attributes }
        }.not_to change(User, :count)
      end

      it "renders the new template with unprocessable_entity status" do
        post :create, params: { user: invalid_attributes }
        expect(response).to have_http_status(:unprocessable_entity)
        expect(response).to render_template(:new)
      end
    end
  end

  describe "GET #show" do
    let(:user) { User.create!(name: "Jane", address: "Hyd", phone: "9999999999", dob: Date.new(1995, 1, 1), initial_deposit: 2000) }
    let!(:account) { user.create_account(balance: 2000) }

    it "assigns the requested account" do
      get :show, params: { id: account.id }
      expect(assigns(:account)).to eq(account)
      expect(response).to be_successful
    end
  end

  describe "GET #index" do
    let(:user1) { User.create!(name: "A", address: "Hyd", phone: "9999999991", dob: Date.new(1990,1,1), initial_deposit: 1000) }
    let(:user2) { User.create!(name: "B", address: "Hyd", phone: "9999999992", dob: Date.new(1991,1,1), initial_deposit: 2000) }
    let!(:account1) { user1.create_account(balance: 1000) }
    let!(:account2) { user2.create_account(balance: 2000) }

    it "assigns all accounts to @accounts" do
      get :index
      expect(assigns(:accounts)).to match_array([account1, account2])
      expect(response).to be_successful
    end
  end
end
