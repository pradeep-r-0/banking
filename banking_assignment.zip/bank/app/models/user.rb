class User < ApplicationRecord
  has_one :account, dependent: :destroy

  # Virtual attribute — not stored in the DB
  attr_accessor :initial_deposit

  validates :name, presence: true
  validates :phone, presence: true
  validates :address, presence: true
end
