class AccountsController < ApplicationController
  def new
    @user = User.new
  end

  def create
    @user = User.new(user_params)
    if @user.save
      # Create the linked account using the virtual attribute
      initial_deposit = @user.initial_deposit.to_f
      @user.create_account(balance: initial_deposit)

      redirect_to @user.account, notice: "Account successfully created!"
    else
      render :new, status: :unprocessable_entity
    end
  end

  def show
    @account = Account.find(params[:id])
  end

  def index
    @accounts = Account.all
  end

  private

  def user_params
    params.require(:user).permit(:name, :address, :dob, :phone, :initial_deposit)
  end
end
