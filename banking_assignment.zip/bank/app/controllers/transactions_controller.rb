class TransactionsController < ApplicationController
  before_action :set_account, only: [:deposit, :withdrawal, :transfer]

  def deposit
    if request.post?
      amount = params[:amount].to_f
      @account.balance += amount
      if @account.save
        redirect_to @account, notice: "Successfully deposited ₹#{amount}."
      else
        render :deposit, alert: "Deposit failed."
      end
    end
  end

  def withdrawal
    if request.post?
      amount = params[:amount].to_f
      if @account.balance >= amount
        @account.balance -= amount
        @account.save
        redirect_to @account, notice: "Successfully withdrew ₹#{amount}."
      else
        flash.now[:alert] = "Insufficient balance!"
        render :withdrawal
      end
    end
  end

  def transfer
    if request.post?
      from_account = @account
      to_account = Account.find_by(id: params[:to_account_id])
      amount = params[:amount].to_f

      if to_account && from_account.balance >= amount
        from_account.update(balance: from_account.balance - amount)
        to_account.update(balance: to_account.balance + amount)
        redirect_to from_account, notice: "Transferred ₹#{amount} to Account ##{to_account.id}."
      else
        flash.now[:alert] = "Invalid target account or insufficient balance!"
        render :transfer
      end
    end
  end

  private

  def set_account
    @account = Account.find(params[:account_id])
  end
end
