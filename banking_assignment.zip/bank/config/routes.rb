Rails.application.routes.draw do
  get "accounts/new"
  get "accounts/create"
  get "accounts/show"
  get "accounts/index"
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Reveal health status on /up that returns 200 if the app boots with no exceptions, otherwise 500.
  # Can be used by load balancers and uptime monitors to verify that the app is live.
  get "up" => "rails/health#show", as: :rails_health_check

  # Render dynamic PWA files from app/views/pwa/*
  get "service-worker" => "rails/pwa#service_worker", as: :pwa_service_worker
  get "manifest" => "rails/pwa#manifest", as: :pwa_manifest

  resources :accounts do
    resources :transactions, only: [:new, :create, :index, :show] do
      collection do
        get :deposit
        post :deposit
        get :withdrawal
        post :withdrawal
        get :transfer
        post :transfer
      end
    end
  end

  get 'home/index'
  # Defines the root path route ("/")
   root "home#index"
end
